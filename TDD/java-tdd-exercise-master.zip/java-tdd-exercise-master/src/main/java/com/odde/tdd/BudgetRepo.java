package com.odde.tdd;

import java.util.List;

public interface BudgetRepo {
    List<Budget> findAll();
}
